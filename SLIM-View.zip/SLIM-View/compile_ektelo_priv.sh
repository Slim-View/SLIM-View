#!/bin/bash -x

cd ./src/ektelo/ektelo/algorithm/
./setup.sh

cd ./src/competitors/privbayes/
make