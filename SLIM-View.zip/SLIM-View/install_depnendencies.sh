virtualenv venv 
source venv/bin/activate
pip3 install tensorflow==2.9.2 --no-cache-dir
pip3 install attrs==21.4.0 dp-accounting==0.1.2 matplotlib==3.6.2 pandas==1.5.1 scikit-learn==1.1.3 tensorflow-datasets==4.5.2 tensorflow-probability==0.15 --no-cache-dir

pip3 install farmhashpy==0.4.0 portpicker==1.5 semantic-version==2.6 tensorflow-model-optimization==0.7.3 tensorflow-privacy==0.5.1 --no-dependencies --no-cache-dir

pip3 install tensorflow-metal==0.5.1 numpy==1.23.4 --no-cache-dir
pip3 install tensorflow-federated==0.34.0 --no-deps --no-cache-dir
pip3 install torch
pip3 install torchvision
pip3 install xgboost
pip3 install futur
pip3 install gmpy2
pip3 install pymoo==0.5.0
