#include <vector>

std::string c_get_model(const int* data,const std::string& config, double eps, double theta, int seed, int m, int n);