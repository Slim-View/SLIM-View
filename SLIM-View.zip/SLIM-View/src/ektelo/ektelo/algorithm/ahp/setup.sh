
rm ahp_fast.c
rm *.so
python setup.py build_ext --inplace



