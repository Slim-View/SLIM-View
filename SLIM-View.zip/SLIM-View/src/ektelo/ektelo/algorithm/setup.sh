echo 'Setup dawa'
cd ./dawa && ./setup.sh && cd ..

echo 'Setup ahp'
cd ./ahp && ./setup.sh && cd ..

echo 'Setup PrivBayes'
cd ./privBayes && ./setup.sh && cd ..
