- based on https://sourceforge.net/projects/privbayes/ [1]

---
[1] PrivBayes: Private Data Release via Bayesian Networks [TODS17]