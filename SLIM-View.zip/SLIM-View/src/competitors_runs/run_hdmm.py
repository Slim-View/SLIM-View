import queue
import sys
from pathlib import Path
sys.path.append(str(Path('').resolve()))
import time
import pandas as pd
import numpy as np
import math
from src.hdpview.domain import Domain

from src.competitors.hdmm.src.hdmm import templates
from src.competitors.hdmm.src import hdmm as hdmm
from src.hdpview.workload_generator  import Pmatrix
from tqdm import tqdm
from src.competitors.hdmm.src.hdmm.matrix import EkteloMatrix
from src.competitors.hdmm.src.hdmm import workload

def run(dataset_org,method,workloads,epsilon,synth):

    prng = np.random.RandomState(0)

    rmse_g = []
    re_g= []
    view_times =[]
    workloads_times=[]
    for indice in tqdm(range(1),"workload loop : ",leave=True):
        workload  = workloads[indice]

        dataset = dataset_org.df.copy()
        dataset_shape = dataset_org.domain.shape
        #workload  = workload[0]
        dims = list(workload.attrs)
        columns_to_drop = [index for index,value in enumerate(dataset.columns) if value not in dims]
        columns_to_not_drop = [index for index,value in enumerate(dataset.columns) if value in dims]


        shape =[]
        bins = []
        for i in columns_to_not_drop:
            bins.append(range(dataset_shape[i]+1))
            shape.append(dataset_shape[i])

        dataset_c = dataset.drop(dataset.columns[columns_to_drop], axis=1) 
        ans = np.histogramdd(dataset_c.values, bins)[0]
        x = ans.flatten()
    
        
        rmse = 0
        re = 0
        algo_exe_time = 0

        for i in tqdm(range(10),"Iteration loop : ",leave=True):

            

            W = workload
            x = np.transpose(x)
            x_res= None

            
            start = time.time()
            counts = [dataset_org.domain.shape[index] for index in columns_to_not_drop]
            domain = Domain(dims,counts)

            hdmm_template = templates.KronPIdentity(Pmatrix(domain), domain.shape)
            hdmm_template.optimize(workload)
        
            #rootmse = error.rootmse2(workload, hdmm_template.strategy(),x, eps=epsilon)
            A = hdmm_template.strategy()
            W, A = convert_implicit(W), convert_implicit(A)
            delta = A.sensitivity()
            AtA = A.gram()
            AtA1 = AtA.pinv()
            x_e = AtA * x
            x_ep = [elem + np.random.laplace(loc=0,scale=delta/epsilon) for elem in x_e]

            x_ep = np.array(x_ep)
            x_res = AtA1 * x_ep
            algo_exe_time += (time.time()- start)/10
            

            x_res = np.transpose(x_res)

            est = W * x_res
            true = W * x

            est = np.array( est)
            true = np.array(true)

           

            est = np.array(est)
            true = np.array(true)
            sq_err = np.square(est - true)
            rmse += math.sqrt(np.mean(sq_err))/10

        rmse_g.append(rmse)
        view_times.append(algo_exe_time)
    
    return rmse_g,re_g,view_times

            

    

def get_attribut_qwl(workload):
    dims = []
    for cond in workload[0].conditions:
        dims.append(cond.attribute)
    return dims
def convert_implicit(A):
    if isinstance(A, EkteloMatrix) or isinstance(A, workload.ExplicitGram):
        return A
    return EkteloMatrix(A)

def run_mat_q(Q,x):
    return np.sum([Q[i]*x[i] for i in range(len(Q))])

def mul_array(ar):
    mul = 1
    for e in ar:
        mul = mul*e
    return mul
