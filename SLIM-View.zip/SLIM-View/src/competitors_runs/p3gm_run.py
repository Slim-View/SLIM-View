import sys
from pathlib import Path
sys.path.append(str(Path('').resolve()))
import time

import subprocess

from pathlib import Path
from tqdm import tqdm
import numpy as np
import pandas as pd
import math
import datetime
from src.hdpview.domain import Domain

import torch
print("Cuda version torch  : "+str(torch.version.cuda))
from src.competitors.P3GM.src.p3gm import P3GM
import src.competitors.P3GM.ml_task.exp_ml
import src.competitors.P3GM.src.my_util

from src.competitors.P3GM.src import my_util,p3gm


class Arg_Class:
    def __init__(self, **entries):
        self.__dict__.update(entries)


def run_p3gm( dataset_org,workloads,synth=False):
    # These
    args_ = {"lot_size": 100,"sgd_sigma": 1.4,"sgd_epoch": 2,"clipping": 1,"lr": 0.001,"p3gm_delta": 1e-05,"gmm_sigma": 100,"gmm_n_comp": 1,"gmm_iter": 20,"pca_sigma": 5.0,"z_dim": 30,"latent_dim": 1000,"num_microbatches": 100,"n_iter": 1,"skip_ml": False,"eval_each_epoch": False,"nopretrain": False,"time": "20231211-153843"}


    args = Arg_Class(**args_)
    rmse_g = []
    re_g=[]
    view_times =[]
    workloads_times=[]

    for indice in tqdm(range(10),"workload loop : ",leave=True):
        workload  = workloads[indice]
        dataset = dataset_org.df.copy()
        dims = get_attribut_qwl(workload)
        columns_to_drop = [index for index,value in enumerate(dataset.columns) if value not in dims]
        columns_to_not_drop = [index for index,value in enumerate(dataset.columns) if value in dims]
    
        global_dataset =[]
        # (1) Constructing the dataset that will have the same dims as the QWL
        dataset['Mesure'] = 1
        dataset = dataset.drop(dataset.columns[columns_to_drop], axis=1) 
        global_dataset = dataset.groupby(dims).sum().reset_index()
            #print(global_dataset.shape)

        
        counts = [dataset_org.domain.shape[index] for index in columns_to_not_drop]
            
        counts.append(global_dataset['Mesure'].max())
        domain = Domain(global_dataset.columns,counts)
        
        mins_d =[global_dataset[dim].min() for dim in dims]
        maxs_d =[global_dataset[dim].max() for dim in dims]
        
        mins_d.append(global_dataset['Mesure'].min())
        maxs_d.append(global_dataset['Mesure'].max())

        rmse =0
        algo_exe_time = 0
        query_exe_times_true = [0] * len(workload)
        query_exe_times_est = [0] * len(workload)

        torch.manual_seed(0)

        random_state = np.random.RandomState(0)

        # split the data to train and test 
        msk = np.random.rand(len(global_dataset)) < 0.8
        train = global_dataset[msk]
        test = global_dataset[~msk]
        

        X, encoders, keys, dims = my_util.load_dataset(train,domain)
        X_test, _, _, _ = my_util.load_test_dataset(test,domain)
        data_size = len(X)
        args.lot_size = np.min([args.lot_size,data_size])
        train_loader = my_util.make_dataloader(X,args.lot_size , random_state=random_state, test_data=X_test, encoders=encoders, keys=keys)
        P3GM.cp_epsilon(len(X), args.lot_size, args.pca_sigma, args.gmm_sigma, args.gmm_iter, args.gmm_n_comp, args.sgd_sigma, args.sgd_epoch, args.p3gm_delta)

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")#
        model = P3GM(X.shape[1], device, z_dim=args.z_dim, latent_dim=args.latent_dim).to(device)

        parameters = vars(args)
        parameters["p3gm_epsilon"] = P3GM.cp_epsilon(len(X), args.lot_size, args.pca_sigma, args.gmm_sigma, args.gmm_iter, args.gmm_n_comp, args.sgd_sigma, args.sgd_epoch, args.p3gm_delta)
        dt_now = datetime.datetime.now()
        now_time = dt_now.strftime('%Y%m%d-%H%M%S')
        parameters["time"] = now_time
        
        start_time = time.time()
        # training
        model.train(train_loader, random_state=random_state, **parameters)
        algo_exe_time = time.time()  - start_time


        reps = 10
        for i in tqdm(range(reps),"Iteration loop : ",leave=True):
            

            #print("Generating data !")
            perturbed_df = model.generate_data_to_csv(train_loader.get_data_size(), train_loader.get_test_data(), train_loader.encoders, train_loader.keys, i, "out")

            perturbed_df.columns = global_dataset.columns
            
            # (8) Evaluating the algorithm (Using RMSE mesure)
            est =[]
            true =[]

            for index, query in enumerate(workload):
                res_q, time_exe = run_query_on_df(global_dataset,query)
                true.append(res_q)
                query_exe_times_true[index] += time_exe/reps
                res_q, time_exe = run_query_on_df(perturbed_df,query)
                est.append(res_q)
                query_exe_times_est[index] += time_exe/reps
            
           
        
            est = np.array(est)
            true = np.array(true)
            rmse_1 = math.sqrt(np.mean(np.square(est - true)))
            rmse += rmse_1/reps
           

            
        rmse_g.append(rmse)
        view_times.append(algo_exe_time)
        workloads_times.append([query_exe_times_true,query_exe_times_est])
    return rmse_g,re_g,view_times,workloads_times







def run_query_on_df(df,query):
    start_time = time.time()
    boolean_index_org = (df[query.conditions[0].attribute] >= query.conditions[0].start) & (df[query.conditions[0].attribute] <= query.conditions[0].end)
    for cond in query.conditions[1:]:
        boolean_index_org = boolean_index_org & (df[cond.attribute] >= cond.start) & (df[cond.attribute] <= cond.end )           
    res = df[boolean_index_org]['Mesure'].sum()
    end_time = time.time()
    return res, end_time-start_time
def get_attribut_qwl(workload):
    dims = []
    for cond in workload[0].conditions:
        dims.append(cond.attribute)
    print(dims)
    return dims
