import sys
import time
import pickle

import numpy as np
import math
from tqdm import tqdm

from src.competitors.PrivSyn.method.dpsyn import DPSyn
from src.competitors.PrivSyn.data.DataLoader import *
from src.competitors.PrivSyn.data.RecordPostprocessor import RecordPostprocessor


def run(dataset_org,epsilon,workloads):
    rmse_g = []
    re_g=[]
    compressions =[]
    view_times =[]
    workloads_times=[]
    for indice in tqdm(range(len(workloads)),"workload loop : ",leave=True):
        workload  = workloads[indice]
        
        

        dataset = dataset_org.df.copy()
        #workload  = workload[0]
        dims = get_attribut_qwl(workload)
        columns_to_drop = [index for index,value in enumerate(dataset.columns) if value not in dims]
        columns_to_not_drop = [index for index,value in enumerate(dataset.columns) if value in dims]
    

        global_dataset =[]
        # (1) Constructing the dataset that will have the same dims as the QWL
        dataset['Mesure'] = 1
        dataset = dataset.drop(dataset.columns[columns_to_drop], axis=1) 
        global_dataset = dataset.groupby(dims).sum().reset_index()
        global_dataset_mesure = global_dataset.copy()

        counts = [dataset_org.domain.shape[index] for index in columns_to_not_drop]
        counts.append(global_dataset['Mesure'].max())

        # dataloader initialization
        dataloader = DataLoader()
        dataloader.load_data_2(global_dataset,global_dataset.columns,counts)
        
        n = global_dataset.shape[0]

        eps, delta, sensitivity = 0.1,0.00000000001,1

        rmse = 0
        algo_exe_time = 0
        query_exe_times_true = [0] * len(workload)
        query_exe_times_est = [0] * len(workload)

        synthesizer = DPSyn(dataloader, eps, delta, sensitivity)
        # tmp returns a DataFrame
        attrs, domains, clusters, num_records = synthesizer.synthesize(fixed_n=n)

        for i in tqdm(range(10),"Iteration loop : ",leave=True):

            
            
            
            synthesizer.synthesize_records(attrs, domains, clusters, num_records)
            synth_data =  synthesizer.synthesized_df

            # postprocessor = RecordPostprocessor()
            # synth_data = postprocessor.post_process(synth_data,dataloader.config,dataloader.decode_mapping)
    
       
            

           
            est = []
            true=[]
            for index,query in enumerate(workload):
                res,times = run_query_on_df(global_dataset_mesure,query)
                true.append(res)
                query_exe_times_true[index] = times/10

                q_start = time.time()
                res,times = run_query_on_df(synth_data,query)
                q_end = time.time()
                est.append(res)
                query_exe_times_est[index] = (q_end-q_start)/10

            

            est = np.array(est)
            true= np.array(true)
            sq_err = np.square(est - true)
            rmse += math.sqrt(np.mean(sq_err))/10

        
        workloads_times.append([query_exe_times_true,query_exe_times_est])
        view_times.append(algo_exe_time)
        rmse_g.append(rmse)


    return rmse_g,view_times,workloads_times


def get_attribut_qwl(workload):
    dims = []
    for cond in workload[0].conditions:
        dims.append(cond.attribute)
    return dims

def run_query_on_df(df,query):
    start_time = time.time()
    boolean_index_org = (df[query.conditions[0].attribute] >= query.conditions[0].start) & (df[query.conditions[0].attribute] <= query.conditions[0].end)
    for cond in query.conditions[1:]:
        boolean_index_org = boolean_index_org & (df[cond.attribute] >= cond.start) & (df[cond.attribute] <= cond.end )           
    res = df[boolean_index_org]['Mesure'].sum()
    end_time = time.time()
    return res, end_time-start_time

