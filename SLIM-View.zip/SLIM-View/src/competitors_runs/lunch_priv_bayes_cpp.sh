#!/bin/sh

script_p="$(readlink -f "$0")"
directory_p="$(dirname "$current_script")"
parent_p="${parent_directory%/*}/competitors/privbayes"

cd $parent_p && ./privBayes.bin gendim cq 1 0.1

