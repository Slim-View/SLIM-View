import sys
from pathlib import Path
sys.path.append(str(Path('').resolve()))

import pandas as pd

from tqdm import tqdm
from pathlib import Path

import argparse
from src.hdpview.dataset import Dataset
from src.hdpview.workload_generator import *


from src.SLIMView import SLIMView


if __name__ == "__main__":

       for name_dataset_exp in tqdm(["nume-adult","trafic","bitcoin","electricity","adult"],"Dataset loop : ",leave=False):#"bitcoin","electricity","trafic",

            root_dir = Path('__file__').resolve().parent
            data_dir = root_dir / "data" / "preprocessed" / name_dataset_exp
            
            

            data = Dataset.load(data_dir / 'data.csv', data_dir / 'domain.json')

            epsilon = 0.1

        

            direct_workloads = [] 

        
                
            for i in range(1):
                if name_dataset_exp =="adult":
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=100, dim_size=7, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=100, dim_size=8, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=100, dim_size=9, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=100, dim_size=10, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=100, dim_size=11, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=100, dim_size=12, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=100, dim_size=13, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=100, dim_size=14, seed=i))
                else :
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=2, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=3, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=4, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=5, seed=i))
                    direct_workloads.append(direct_random_range_queries(domain=data.domain, size=3000, dim_size=6, seed=i))
                
                
                

            nbr_dims = 2
            sum_workloads = 0
            for i in tqdm(range(len(direct_workloads)),"direct-workload loop : ",leave=False):
                
                    direct_workload_name, direct_workload = direct_workloads[i]
                    sum_workloads+=len(direct_workload)

                    rmse_g,_,compressions,view_times,_ = SLIMView.run(data,0.05,direct_workload,0.5,epsilon,0.5,False,False)
                    data_sensi = {
                                        "RMSE" : rmse_g,
                                        "CR" : compressions,
                                        "ET" : view_times,
                                    }
                    df = pd.DataFrame(data_sensi)
                    df.to_csv("exp-SLIM-VIEW-"+name_dataset_exp+"-"+direct_workload_name+".csv")
            

                    
