source venv/bin/activate
python3 src/script/count_query_eval_PrivBayes.py