# SLIM-View (SampLing dIfferentially Materialized View)

  

This code is associated to the work we submitted to **CODASPY 2024**

To run the experiments you need to :
- Install all the rependencies 
> ./install_depnendencies.sh

- Download the datasets
> ./download_dataset.sh

- Run experiments :
	- SLIM-View
	 > ./lunch_slim_view.sh
    - SLIM-View-WW (Without workload)
	 > ./lunch_slim_view_ww.sh
	- Partitioning HDPView and PrivTree
		> ./lunch_hdp.sh
        > ./lunch_privtree.sh
	- Workload-dependent HDMM
		> ./lunch_hdmm.sh
	- Generative-model PrivBayes and P3GM
		> Fix the path in the file : src/competitors/privbayes/code/main_marginal.cpp
		>./compile_ektelo_priv.sh
		> ./lunch_gen_exp.sh
